package com.perscholas.springmvc_jpa.hibernate_session;

import org.hibernate.SessionFactory;

public interface HibernateUtil {
	SessionFactory getSessionFactory();
}